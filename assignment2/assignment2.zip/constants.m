I = 1;
J = 2;
K = 3;

% DH parameters of PUMA 560 in home position, according to assgt 2

alpha1 = -90;

a2 = 430;
alpha2 = 180;

DHtheta3 = 90;
d3 = -149.1;
a3 = 20.3;
alpha3 = 90;

d4 = 435;
alpha4 = 90;

alpha5 = -90;

d6 = 60;